import "./globals.css";

export const metadata = {
  title: "방콕 오만찬 맛집 찾기",
  description: "로그인 없이 지역/카테고리/태그로 방콕 맛집을 빠르게 찾는 앱"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
