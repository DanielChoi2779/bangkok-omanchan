"use client";

import { useMemo, useState } from "react";
import raw from "../data/restaurants.json";

type Restaurant = {
  name: string;
  area: string;
  category: string;
  tags: string[];
  mapUrl: string;
};

const data = raw as Restaurant[];

function uniq(arr: string[]) {
  return Array.from(new Set(arr)).sort((a, b) => a.localeCompare(b, "ko"));
}

export default function Page() {
  const [q, setQ] = useState("");
  const [area, setArea] = useState("전체");
  const [category, setCategory] = useState("전체");
  const [tag, setTag] = useState("전체");

  const areas = useMemo(() => ["전체", ...uniq(data.map((d) => d.area))], []);
  const categories = useMemo(() => ["전체", ...uniq(data.map((d) => d.category))], []);
  const tags = useMemo(() => ["전체", ...uniq(data.flatMap((d) => d.tags || []))], []);

  const filtered = useMemo(() => {
    const query = q.trim().toLowerCase();
    return data.filter((d) => {
      const matchArea = area === "전체" || d.area === area;
      const matchCategory = category === "전체" || d.category === category;
      const matchTag = tag === "전체" || (d.tags || []).includes(tag);

      const hay = `${d.name} ${d.area} ${d.category} ${(d.tags || []).join(" ")}`.toLowerCase();
      const matchQuery = !query || hay.includes(query);

      return matchArea && matchCategory && matchTag && matchQuery;
    });
  }, [q, area, category, tag]);

  return (
    <div style={{ maxWidth: 860, margin: "0 auto", padding: 16, fontFamily: "system-ui, -apple-system, Segoe UI, Roboto" }}>
      <header style={{ position: "sticky", top: 0, background: "white", paddingTop: 10, paddingBottom: 12, zIndex: 10 }}>
        <h1 style={{ margin: 0, fontSize: 22 }}>🇹🇭 방콕 오만찬 맛집 찾기</h1>
        <p style={{ margin: "6px 0 12px", color: "var(--muted)", fontSize: 13 }}>
          로그인 없이 · 검색/필터 · 태그(오만찬/2차/가성비/혼밥/관광픽) · 구글맵 바로 열기
        </p>

        <div style={{ display: "grid", gap: 10 }}>
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="검색: 가게명/메뉴/태그 (예: 팟타이, 굴전, 망고밥, 혼밥)"
            style={{ padding: 12, borderRadius: 12, border: "1px solid var(--border)", outline: "none" }}
          />

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
            <select
              value={area}
              onChange={(e) => setArea(e.target.value)}
              style={{ padding: 12, borderRadius: 12, border: "1px solid var(--border)", background: "white" }}
            >
              {areas.map((a) => (
                <option key={a} value={a}>{a}</option>
              ))}
            </select>

            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              style={{ padding: 12, borderRadius: 12, border: "1px solid var(--border)", background: "white" }}
            >
              {categories.map((c) => (
                <option key={c} value={c}>{c}</option>
              ))}
            </select>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 10 }}>
            <select
              value={tag}
              onChange={(e) => setTag(e.target.value)}
              style={{ padding: 12, borderRadius: 12, border: "1px solid var(--border)", background: "white" }}
            >
              {tags.map((t) => (
                <option key={t} value={t}>{t}</option>
              ))}
            </select>
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <Chip onClick={() => { setArea("전체"); setCategory("전체"); setTag("전체"); setQ(""); }}>초기화</Chip>

            <Chip onClick={() => setTag("오만찬1차")}>오만찬1차</Chip>
            <Chip onClick={() => setTag("2차")}>2차</Chip>
            <Chip onClick={() => setTag("가성비")}>가성비</Chip>
            <Chip onClick={() => setTag("혼밥")}>혼밥</Chip>
            <Chip onClick={() => setTag("관광픽")}>관광픽</Chip>

            <Chip onClick={() => setArea("통러/에까마이")}>통러/에까마이</Chip>
            <Chip onClick={() => setArea("아속/나나")}>아속/나나</Chip>
            <Chip onClick={() => setArea("싸얌/빠뚜남")}>싸얌/빠뚜남</Chip>
            <Chip onClick={() => setArea("씰롬/싸톤")}>씰롬/싸톤</Chip>
          </div>

          <div style={{ color: "var(--muted)", fontSize: 12 }}>
            결과 {filtered.length} / 전체 {data.length}
          </div>
        </div>
      </header>

      <main style={{ display: "grid", gap: 12, paddingBottom: 30 }}>
        {filtered.map((d) => (
          <div key={`${d.name}-${d.mapUrl}`} style={{ border: "1px solid var(--border)", borderRadius: 16, padding: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "baseline" }}>
              <div style={{ fontWeight: 800, fontSize: 16 }}>{d.name}</div>
              <div style={{ color: "var(--muted)", fontSize: 12 }}>{d.area}</div>
            </div>

            <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap" }}>
              <Badge>{d.category}</Badge>
              {(d.tags || []).filter(Boolean).map((t) => (
                <Badge key={t} subtle>#{t}</Badge>
              ))}
            </div>

            <div style={{ marginTop: 12 }}>
              <a
                href={d.mapUrl}
                target="_blank"
                rel="noreferrer"
                style={{
                  display: "inline-block",
                  padding: "10px 12px",
                  borderRadius: 12,
                  border: "1px solid var(--border)",
                  textDecoration: "none"
                }}
              >
                구글맵 열기 →
              </a>
            </div>
          </div>
        ))}

        {filtered.length === 0 && (
          <div style={{ border: "1px dashed var(--border)", borderRadius: 16, padding: 16, color: "var(--muted)" }}>
            조건에 맞는 장소가 없어요.
          </div>
        )}
      </main>
    </div>
  );
}

function Chip({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: "8px 10px",
        borderRadius: 999,
        border: "1px solid var(--border)",
        background: "white",
        cursor: "pointer",
        fontSize: 12
      }}
    >
      {children}
    </button>
  );
}

function Badge({ children, subtle }: { children: React.ReactNode; subtle?: boolean }) {
  return (
    <span
      style={{
        display: "inline-block",
        padding: "4px 8px",
        borderRadius: 999,
        border: "1px solid var(--border)",
        background: subtle ? "#fafafa" : "white",
        fontSize: 12
      }}
    >
      {children}
    </span>
  );
}
